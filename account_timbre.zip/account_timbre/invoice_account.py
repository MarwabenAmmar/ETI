# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


from openerp import models, fields, api, _

import openerp.addons.decimal_precision as dp
from math import *

schu = ["", "UN ", "DEUX ", "TROIS ", "QUATRE ", "CINQ ", "SIX ", "SEPT ", "HUIT ", "NEUF "]
schud = ["DIX ", "ONZE ", "DOUZE ", "TREIZE ", "QUATORZE ", "QUINZE ", "SEIZE ", "DIX SEPT ", "DIX HUIT ", "DIX NEUF "]
schd = ["", "DIX ", "VINGT ", "TRENTE ", "QUARANTE ", "CINQUANTE ", "SOIXANTE ", "SOIXANTE ", "QUATRE VINGT ",
        "QUATRE VINGT "]


def convNombre2lettres(nombre):
    s = ''
    result = nombre - int(floor(nombre))
    reste = int(floor(nombre))
    i = 1000000000
    while i > 0:
        y = reste / i
        if y != 0:
            centaine = y / 100
            dizaine = (y - centaine * 100) / 10
            unite = y - centaine * 100 - dizaine * 10
            if centaine == 1:
                s += "CENT "
            elif centaine != 0:
                s += schu[centaine] + "CENT "
                if dizaine == 0 and unite == 0: s = s[:-1] + "S "
            if dizaine not in [0, 1]: s += schd[dizaine]
            if unite == 0:
                if dizaine in [1, 7, 9]:
                    s += "DIX "
                elif dizaine == 8:
                    s = s[:-1] + "S "
            elif unite == 1:
                if dizaine in [1, 9]:
                    s += "ONZE "
                elif dizaine == 7:
                    s += "ET ONZE "
                elif dizaine in [2, 3, 4, 5, 6]:
                    s += "ET UN "
                elif dizaine in [0, 8]:
                    s += "UN "
            elif unite in [2, 3, 4, 5, 6, 7, 8, 9]:
                if dizaine in [1, 7, 9]:
                    s += schud[unite]
                else:
                    s += schu[unite]
            if i == 1000000000:
                if y > 1:
                    s += "MILLIARDS "
                else:
                    s += "MILLIARD "
            if i == 1000000:
                if y > 1:
                    s += "MILLIONS "
                else:
                    s += "MILLIONS "
            if i == 1000:
                s += "MILLE "
        # end if y!=0
        reste -= y * i
        dix = False
        i /= 1000;
    # end while
    if len(s) == 0: s += "ZERO "

    return (s)


def reste(nombre):
    result = nombre - int(floor((nombre)))
    line1 = 'ZERO'
    line1 = int(round(result * 1000))
    l = "%s" % (line1)
    return line1


class accountTimbre(models.Model):
    _inherit = "account.invoice.line"

    @api.one
    @api.depends('price_unit', 'discount', 'invoice_line_tax_id', 'quantity',
                 'product_id', 'invoice_id.partner_id', 'invoice_id.currency_id')
    def _compute_tva(self):
        price = self.price_unit * (1 - (self.discount or 0.0) / 100.0)
        taxes = self.invoice_line_tax_id.compute_all(price, self.quantity,
                                                     product=self.product_id, partner=self.invoice_id.partner_id)[
            'taxes']
        for tax in taxes:

            if tax['name'] == 'FODEC':
                self.Fodec =( 0.01 * self.price_unit) * self.quantity
                
               
                               
            else:
                self.montant_tva = (tax['amount'])
            

                rem = self.price_unit * ((self.discount or 0.0) / 100.0)
                self.montant_rem = rem
                self.ht = price 
               
    montant_tva = fields.Float(string='Mont TVA', digits=dp.get_precision('Account'), store=True, readonly=True,
                               compute='_compute_tva')
    montant_rem = fields.Float(string='Mont Remise', digits=dp.get_precision('Account'), store=True, readonly=True,
                               compute='_compute_tva')
    Fodec = fields.Float(string='Fodec', compute='_compute_tva')
   
    ht = fields.Float(string='Prix_Unit_HT', digits=dp.get_precision('Account'), store=True, readonly=True,
                      compute='_compute_tva')


class accountInvoice(models.Model):
    _inherit = "account.invoice"

    @api.one
    @api.depends('invoice_line.price_subtotal', 'tax_line.amount')
    def _compute_amount(self):
        timbre = self.env['product.product'].search([('name', '=', 'Timbre Fiscal')])
        if timbre:
            val = timbre[0].list_price
        self.amount_timbre = val
        self.amount_fodec = sum(line.Fodec for line in self.invoice_line)

        self.amount_tax = sum(line.montant_tva for line in self.invoice_line)
        self.amount_remise = sum(line.montant_rem for line in self.invoice_line)
        self.amount_untaxed = sum(
            line.price_subtotal for line in self.invoice_line) + self.amount_remise - self.amount_timbre
        self.amount_net = sum(line.price_subtotal for line in self.invoice_line) - val
        self.amount_total = (sum(line.price_subtotal for line in self.invoice_line)) + (self.amount_tax + self.amount_fodec)
        total = self.amount_total
        chaine = convNombre2lettres(total)
        chaine2 = reste(total)
        self.lettre = "%s DINARS ET %s MILLIMES" % (chaine, chaine2)

    amount_remise = fields.Float(string='Total Remise', digits=dp.get_precision('Account'),
                                 store=True, readonly=True, compute='_compute_amount', track_visibility='always')
    amount_net = fields.Float(string='Montant Net HT', digits=dp.get_precision('Account'),
                              store=True, readonly=True, compute='_compute_amount')
    amount_timbre = fields.Float(string='Timbre Fiscal', digits=dp.get_precision('Account'),
                                 store=True, readonly=True, compute='_compute_amount')
    amount_fodec = fields.Float(string='Fodec', digits=dp.get_precision('Account'),
                                store=True, readonly=True, compute='_compute_amount')

    lettre = fields.Char(string='Total en lettre', readonly=True,
                         states={'draft': [('readonly', False)]}, compute='_compute_amount')

    @api.multi
    def invoice_print(self):
        """ Print the invoice and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        assert len(self) == 1, 'This option should only be used for a single id at a time.'
        self.sent = True
        return self.env['report'].get_action(self, 'account.invoice')
